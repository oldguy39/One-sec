package com.john.onesecoff;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.ImageFormat;
import android.graphics.Matrix;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.FaceDetector;
import android.media.Image;
import android.media.ImageReader;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.util.Size;

import java.nio.ByteBuffer;
import java.util.Collections;

/**
 * One short look through the front camera: "is someone looking at the phone?"
 *
 * Battery design:
 *  - Camera opens only for the check (about half a second), then closes completely.
 *  - Uses the smallest camera picture (about 320x240) and Android's built-in
 *    face finder, so there is no AI download and nothing runs in between checks.
 */
class FaceCheck {

    interface Result { void onResult(boolean faceSeen); }

    private static final int  SKIP_FRAMES = 3;    // let the camera adjust to the light first
    private static final int  MAX_FRAMES  = 8;    // give up after this many pictures
    private static final long TIMEOUT_MS  = 1500; // hard stop, whatever happens

    private final CameraManager cm;
    private final Handler main = new Handler(Looper.getMainLooper());

    private String camId;
    private int sensorRotation = 270;
    private Size size;

    // Everything below is used only on the background camera thread.
    private HandlerThread thread;
    private Handler bg;
    private CameraDevice device;
    private CameraCaptureSession session;
    private ImageReader reader;
    private Result result;
    private boolean done;
    private int frames;

    FaceCheck(Context c) {
        cm = (CameraManager) c.getSystemService(Context.CAMERA_SERVICE);
        try {
            for (String id : cm.getCameraIdList()) {
                CameraCharacteristics ch = cm.getCameraCharacteristics(id);
                Integer facing = ch.get(CameraCharacteristics.LENS_FACING);
                if (facing != null && facing == CameraCharacteristics.LENS_FACING_FRONT) {
                    camId = id;
                    Integer o = ch.get(CameraCharacteristics.SENSOR_ORIENTATION);
                    if (o != null) sensorRotation = o;
                    size = pickSmallSize(ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP));
                    break;
                }
            }
        } catch (Exception ignored) { }
    }

    boolean available() { return camId != null && size != null; }

    private static Size pickSmallSize(StreamConfigurationMap map) {
        if (map == null) return null;
        Size[] sizes = map.getOutputSizes(ImageFormat.YUV_420_888);
        if (sizes == null || sizes.length == 0) return null;
        Size best = null, smallest = null;
        for (Size s : sizes) {
            long area = (long) s.getWidth() * s.getHeight();
            if (smallest == null || area < (long) smallest.getWidth() * smallest.getHeight()) smallest = s;
            if (s.getWidth() >= 320 && s.getHeight() >= 240
                    && (best == null || area < (long) best.getWidth() * best.getHeight())) best = s;
        }
        return best != null ? best : smallest;
    }

    /** Call from the main thread. The answer comes back on the main thread. */
    void start(Result r) {
        thread = new HandlerThread("onesec-face");
        thread.start();
        bg = new Handler(thread.getLooper());
        final HandlerThread myThread = thread;
        final Handler myBg = bg;
        myBg.post(() -> begin(r, myThread, myBg));
    }

    /** Stop a check that is under way (screen went off, etc). */
    void cancel() {
        if (bg != null) {
            final Handler myBg = bg;
            myBg.post(() -> finish(false));
        }
    }

    private void begin(Result r, HandlerThread myThread, Handler myBg) {
        result = r;
        done = false;
        frames = 0;
        myBg.postDelayed(() -> finish(false), TIMEOUT_MS);
        try {
            reader = ImageReader.newInstance(size.getWidth(), size.getHeight(), ImageFormat.YUV_420_888, 2);
            reader.setOnImageAvailableListener(this::onImage, myBg);
            cm.openCamera(camId, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice d) {
                    if (done) { d.close(); return; }
                    device = d;
                    try {
                        d.createCaptureSession(Collections.singletonList(reader.getSurface()),
                                new CameraCaptureSession.StateCallback() {
                                    @Override public void onConfigured(CameraCaptureSession s) {
                                        if (done) { s.close(); return; }
                                        session = s;
                                        try {
                                            CaptureRequest.Builder b =
                                                    d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                                            b.addTarget(reader.getSurface());
                                            s.setRepeatingRequest(b.build(), null, myBg);
                                        } catch (Exception e) { finish(false); }
                                    }
                                    @Override public void onConfigureFailed(CameraCaptureSession s) { finish(false); }
                                }, myBg);
                    } catch (Exception e) { finish(false); }
                }
                @Override public void onDisconnected(CameraDevice d) { d.close(); if (device == d) device = null; finish(false); }
                @Override public void onError(CameraDevice d, int err) { d.close(); if (device == d) device = null; finish(false); }
            }, myBg);
        } catch (Exception e) {   // no permission, camera busy, etc.
            finish(false);
        }
    }

    private void onImage(ImageReader r) {
        Image img = null;
        try {
            img = r.acquireLatestImage();
            if (img == null || done) return;
            frames++;
            if (frames <= SKIP_FRAMES) return;
            if (hasFace(img)) finish(true);
            else if (frames >= MAX_FRAMES) finish(false);
        } catch (Exception e) {
            finish(false);
        } finally {
            if (img != null) img.close();
        }
    }

    /** Runs on the camera thread. Cleanup is posted so it happens after the current picture is released. */
    private void finish(boolean face) {
        if (done) return;
        done = true;
        final Handler myBg = bg;
        final HandlerThread myThread = thread;
        final Result r = result;
        myBg.removeCallbacksAndMessages(null);
        myBg.post(() -> {
            try { if (session != null) session.close(); } catch (Exception ignored) { }
            try { if (device != null) device.close(); } catch (Exception ignored) { }
            try { if (reader != null) reader.close(); } catch (Exception ignored) { }
            session = null; device = null; reader = null;
            myThread.quitSafely();
            if (r != null) main.post(() -> r.onResult(face));
        });
    }

    /** Black-and-white copy of the picture, tried in all four directions
     *  since the phone is lying flat and you could be at any edge. */
    private boolean hasFace(Image img) {
        Image.Plane p = img.getPlanes()[0];
        ByteBuffer buf = p.getBuffer();
        int rowStride = p.getRowStride(), pixStride = p.getPixelStride();
        int w = img.getWidth(), h = img.getHeight();
        int step = (w >= 600) ? 2 : 1;
        int ow = w / step, oh = h / step;

        int[] px = new int[ow * oh];
        for (int y = 0; y < oh; y++) {
            int row = y * step * rowStride;
            for (int x = 0; x < ow; x++) {
                int v = buf.get(row + x * step * pixStride) & 0xff;
                px[y * ow + x] = 0xff000000 | (v << 16) | (v << 8) | v;
            }
        }
        Bitmap gray = Bitmap.createBitmap(px, ow, oh, Bitmap.Config.ARGB_8888);

        try {
            for (int i = 0; i < 4; i++) {
                int rot = (sensorRotation + i * 90) % 360;
                if (faceIn(gray, rot)) return true;
            }
            return false;
        } finally {
            gray.recycle();
        }
    }

    private static boolean faceIn(Bitmap gray, int rotation) {
        Matrix m = new Matrix();
        m.postRotate(rotation);
        Bitmap rotated = Bitmap.createBitmap(gray, 0, 0, gray.getWidth(), gray.getHeight(), m, false);
        int bw = rotated.getWidth() & ~1;   // the face finder needs an even width
        int bh = rotated.getHeight();
        Bitmap b565 = Bitmap.createBitmap(bw, bh, Bitmap.Config.RGB_565);
        android.graphics.Canvas c = new android.graphics.Canvas(b565);
        c.drawBitmap(rotated, 0, 0, null);
        if (rotated != gray) rotated.recycle();
        try {
            FaceDetector fd = new FaceDetector(bw, bh, 1);
            FaceDetector.Face[] faces = new FaceDetector.Face[1];
            int n = fd.findFaces(b565, faces);
            return n > 0 && faces[0] != null && faces[0].confidence() >= 0.3f;
        } finally {
            b565.recycle();
        }
    }
}
